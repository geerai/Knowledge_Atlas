This package contains Track 3 webpages for the 160sp K-ATLAS shell.

Files are written to live directly inside the 160sp directory so the canonical navbar and shared stylesheet can be referenced as:
- ka_canonical_navbar.js
- ka_atlas_shell.css

Included files:
- track3_hub.html
- track3_week_1.html ... track3_week_7_5.html
- track3_weeks.css

Notes:
- Every page includes the canonical navbar slots and breadcrumb data.
- Every page includes the same Track 3 subnav, with the current page highlighted.
- Pages also include a local breadcrumb fallback strip so they remain readable even if the canonical JS is not loaded.
